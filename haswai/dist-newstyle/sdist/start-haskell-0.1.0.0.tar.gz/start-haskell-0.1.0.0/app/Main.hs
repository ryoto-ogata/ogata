{-# LANGUAGE OverloadedStrings #-}
module Main where

import System.IO
import System.Environment (getArgs)
import Control.Exception  -- for SomeException
import Language.C
--import Data.ByteString.Char8
import Data.ByteString
import Data.ByteString.Lazy as L
import qualified MyLib
import Network.Wai as Wai
import Network.HTTP.Simple
import Network.HTTP.Types as HType
import Network.Wai.Handler.Warp as Warp
import Network.Wai.Application.Static as Static
import Network.Wai.Parse
import Data.IORef
import Lucid
import Data.Text
import Data.Text.Encoding

router :: Wai.Application
router req =
  case Wai.pathInfo req of
    [] -> app req
    ["result"] -> reapp req
    ["result","check"] -> chapp req
    ["kihon.php"] -> phpapp req
    _ -> notapp req

app :: Wai.Application
app req respond = do
  respond $ responseLBS status200 [] $ renderBS mainHtml

--app :: Wai.Application
--app req send = do
--  send $ Wai.responseFile HType.status200 [("Content-Type","text/html")] "index2.html" Nothing

mainHtml :: Html ()
mainHtml = html_ $ do
  head_ $ do
    title_ "sample page"
  body_ $ do
    h1_ "Welcome to our site!"
    h2_ $ span_ "enter your code"
    div_ [class_ "sourcecode"] $ do
      form_ [action_ "/result", method_ "post", name_ "form"] $ do
        textarea_ [name_ "textcode", rows_ "30", cols_ "50", spellcheck_ "false"] $ do
          "write here"
        br_ []
        input_ [type_ "submit", value_ "CHECK"]
        --input_ [type_ "button", value_ "Check", onclick_ "click()", name_ "checkButton"]
    --a_ [href_ "/result"] "RESULT"
    --script_ [src_ "/main.js"] empty
    --script_ "document.write('HELLO')"
    --script_ "function click(){document.write('hello')}"
    br_ []
    h3_ "Welcome to our site!"

reapp :: Wai.Application
reapp req send = do --reqにはいっている
    (params, _) <- UrlEncoded body
    let mValue = lookup "key" params
    case mValue of
        Just value -> send $ responseLBS status200 [] (L.fromStrict (encodeUtf8 value))
        Nothing    -> send $ responseLBS status400 [] "Bad Request"
  where
    body = requestBody req

  --send $ Wai.responseFile HType.status200 [("Content-Type","text/html")] "index2.html" Nothing

chapp :: Wai.Application
chapp req send = do
  --outputStrings "index2.html" strlist
  send $ Wai.responseFile HType.status200 [("Content-Type","text/html")] "index2.html" Nothing

phpapp :: Wai.Application
phpapp req send = do
  send $ Wai.responseFile HType.status200 [("Content-Type","text/html")] "kihon.php" Nothing

notapp :: Wai.Application
notapp req send
  = send $ Wai.responseBuilder HType.status404 [] "not found"

outputStrings :: FilePath -> [String] -> IO ()
outputStrings filename xs = do
  handle <- openFile filename WriteMode
  mapM_ (System.IO.hPutStrLn handle) xs
  hClose handle

lenfunc :: Int -> Int -> [String] -> [String]
lenfunc len num list
    | (len >= num) = lenfunc len (num+1) (list++[show num])
    | otherwise = list

appendindent :: Int -> String -> String
appendindent num str
  | (num > 0) = appendindent (num-1) ("&nbsp;"++str)
  | otherwise = str

inden :: [Int] -> [String] -> [String] -> [String]
inden (i:is) (l:ls) list
  | (i > 0) = inden is ls (list++[appendindent i l])
  | otherwise = inden is ls (list++[l])
inden _ _ list = list

colorchange :: String -> [Int] -> String
colorchange str (i:is)
  | (str == (show i)) = ("<font color='red'><strong>"++str++"</strong></font>")
  | otherwise = colorchange str is
colorchange str _ = str

fontcol :: [String] -> [Int] -> [String] -> [String]
fontcol (s:ss) boo strlist = fontcol ss boo (strlist++[colorchange s boo])
fontcol _ _ strlist = strlist

specialchara :: String -> String -> String
specialchara (s:ss) str
  | (s == '<') = specialchara ss (str++"&lt")
  | (s == '>') = specialchara ss (str++"&gt")
  | otherwise = specialchara ss (str++[s])
specialchara _ str = str

specialsearch :: Int -> String -> Int
specialsearch num (x:xs)
  | (x == '<')= specialsearch (num+1) xs
  | otherwise = specialsearch num xs
specialsearch num _ = num

special :: [String] -> [String] -> [String]
special (s:ss) str = special ss (str++[specialchara s ""])
special _ str = str

main :: IO ()
main = do
    args <- getArgs
    MyLib.someFunc
    source <- Prelude.readFile $ args !! 0
    let (strs, lists, indent, boo) = MyLib.search source
    let list = Prelude.map (++ "<br>") lists
    let strss = special strs []
    let strip = Prelude.map MyLib.stripStart strss
    let indentstr = inden indent strip []
    let str = Prelude.map (++ "<br>") indentstr
    let leng = Prelude.length str
    let lengt = lenfunc leng 1 []
    --print boo
    --let ind = Prelude.map ("<font color='red'>"++) indentstr
    --let indstr = Prelude.map (++"</font>") ind
    let le = fontcol lengt boo []
    let strlen = Prelude.map (++ "<br>") le
    --print str
    --print indent
    --print indentstr
    --print strss
    
    let strlist = ["<!DOCTYPE html>",
                   "<html>",
                   "<head>",
                   "<meta http-equiv='Conten-Type' content='text/html'; charset=UTF-8>",
                   "<title>TITLE</title>",
                   "<style type='text/css'>",
                   "p3{color:blue}",
                   ".contentA{",
                   "width:5%;",
                   "height:auto;",
                   "}",
                   ".contentB{",
                   "width:35%;",
                   "height:auto;",
                   "}",
                   ".contentC{",
                   "width:60%;",
                   "height:auto;",
                   "}",
                   ".main{",
                   "display:flex;",
                   "}",
                   "</style>",
                   "</head>",
                   "<body>",
                   "<h2><strong>RESULT</strong></h2>",
                   "<div class='main'>",
                   "<div class='contentA'>"]++strlen++["</div>",
                   "<div class='contentB', style='background-color:lightyellow'>"]++str++["</div>",
                   "<div class='contentC'>",
                   "<p3><strong>ERROR</strong></p3><br>",
                   "<p4>"]++list++["</p4>",
                   "</div>",
                   "</div>",
                   "</body>",
                   "</html>"]
    
    --let strlist = []
    outputStrings "index2.html" strlist
    System.IO.putStrLn $ "http://localhost:8080/"
    Warp.run 8080 router
    --Warp.run 8080 hello
    --res <- httpLBS "https://example.com"
    --print (getResponseBody res)